# Windows Calculator Application
This is a C# introductory level project that was geared towards learning the language and Windows Forms by building a basic calculator application. This project began as my take on an Instructables project that can be found <a href="http://www.instructables.com/id/Creating-a-Calculator-Visual-Studio-C/">here</a>, but I currently have plans to evolve this into a far more dynamic program.

The current plan includes for this application to contain:
  - <strike>Basic calculator</strike> <b>COMPLETE</b>
  - Scientific calculator
  - Sales tax calculator
